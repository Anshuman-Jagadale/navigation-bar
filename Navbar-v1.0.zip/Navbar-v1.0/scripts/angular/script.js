(function() {
    angular.module('inspiraApp', [])
        .controller('inspiraCtrl', function($scope, $http) {
            
			/* Enable CORS
			$http.get("data.json")
					  .then(function(response) {
						$scope.menuData = response.data;
			});*/
			
			$scope.menuData = [{
                    "name": "Home",
                    "link": "#",
                    "child": [

                    ]
                },
				{
                    "name": "Links",
                    "link": "#",
                    "child": [ {
                                    "name": "INT3",
                                    "link": "#",
                                    "child": [

                                    ]
                                },
                                {
                                    "name": "SIT6",
                                    "link": "#",
                                    "child": [

                                    ]
                                }
                    ]
                },
                {
                    "name": "Tools",
                    "link": "#",
                    "child": [{
                            "name": "MQ Topic Handler",
                            "link": "#",
                            "child": [{
                                    "name": "Generic Topic Publisher",
                                    "link": "#",
                                    "child": [

                                    ]
                                },
                                {
                                    "name": "Generic Topic Subscriber",
                                    "link": "#",
                                    "child": [

                                    ]
                                },
                                {
                                    "name": "Topic Subscriber",
                                    "link": "#",
                                    "child": [

                                    ]
                                }
                            ]
                        },
                        {
                            "name": "Access Token Generator",
                            "link": "#",
                            "child": [{
                                    "name": "Generate Access Token Scope 30",
                                    "link": "#",
                                    "child": [

                                    ]
                                },
                                {
                                    "name": "Generate Access Token Scope 40",
                                    "link": "#",
                                    "child": [

                                    ]
                                }
                            ]
                        }
                    ]
                },
                {
                    "name": "Virtual Mobile",
                    "link": "#",
                    "child": [{
                            "name": "Mobile SMS Reader",
                            "link": "#",
                            "child": [

                            ]
                        },
                        {
                            "name": "Fetch OTP",
                            "link": "#",
                            "child": [

                            ]
                        },
                        {
                            "name": "Softtoken Authentication",
                            "link": "#",
                            "child": [{
                                    "name": "SME Login Softtoken Authentication",
                                    "link": "#",
                                    "child": [

                                    ]
                                },
                                {
                                    "name": "Payments Softtoken Authentication",
                                    "link": "#",
                                    "child": [

                                    ]
                                }
                            ]
                        }
                    ]
                },
                {
                    "name": "Utilities",
                    "link": "#",
                    "child": [{
                            "name": "Base64",
                            "link": "#",
                            "child": [{
                                    "name": "Base64 Cryptography",
                                    "link": "#",
                                    "child": [

                                    ]
                                },
                                {
                                    "name": "Base64 to PDF File",
                                    "link": "#",
                                    "child": [

                                    ]
                                }
                            ]
                        },
                        {
                            "name": "JSON,XML & SQL Beautifier",
                            "link": "#",
                            "child": [

                            ]
                        }
                    ]
                },
                {
                    "name": "Data Fetcher",
                    "link": "#",
                    "child": [{
                            "name": "Customer Data Retriever",
                            "link": "#",
                            "child": [

                            ]
                        },
                        {
                            "name": "Easy Query",
                            "link": "#",
                            "child": [

                            ]
                        }
                    ]
                }
            ]
        });
}())