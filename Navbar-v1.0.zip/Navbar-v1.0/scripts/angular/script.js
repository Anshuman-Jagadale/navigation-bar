var app = angular.module("inspiraApp", ["ngRoute"]);

app.config(function($routeProvider) {
  $routeProvider
  .when("/homePage", {
    templateUrl : 'welcome.html'
  })
  .when("/red", {
    templateUrl : "red.htm"
  })
  .when("/green", {
    templateUrl : "green.htm"
  }).otherwise({
			redirectTo: "/homePage"
  });
});


app.controller("inspiraCtrl", function ($scope, $http) {  
 	$http.get("data.json").then(function(response) {
		$scope.menuData = response.data;
	});
});  




